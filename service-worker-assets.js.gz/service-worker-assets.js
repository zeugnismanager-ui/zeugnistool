self.assetsManifest = {
  "version": "si8DM8zx",
  "assets": [
    {
      "hash": "sha256-9kmWAqFrsbu8vzKCx/q1/Y0LnrN842eqMPkmTh5Irf0=",
      "url": "_framework/DocumentFormat.OpenXml.69ode73m8c.wasm"
    },
    {
      "hash": "sha256-sOgH/HaY/v66K1lL7mRNdKZeZfoZPxf22KzE8Kw2Bl4=",
      "url": "_framework/DocumentFormat.OpenXml.Framework.w89iktzfdp.wasm"
    },
    {
      "hash": "sha256-TdOouYZXnv6le1EZ9GmOJNnTYGaG/ifTA/mxT9HedQM=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.n76do19qqa.wasm"
    },
    {
      "hash": "sha256-nLu3q7fqnlRWxkSBOiSW/6Ym+q+WI7oVFqVoFHYhGQM=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.8p96lorck9.wasm"
    },
    {
      "hash": "sha256-wRW0VyOHHLdaTyL/Kn/qdztXTTv9+aHgNrWfTgQ/7RM=",
      "url": "_framework/Microsoft.AspNetCore.Components.dpjwawm7lx.wasm"
    },
    {
      "hash": "sha256-rUJo4B/9fTGwpUe8w6Ed05z0ialGql3TEGVJv8eCrQY=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.fxya2zkw7r.wasm"
    },
    {
      "hash": "sha256-sOmlPbN5xqIVkGWOxYMadpCiG4Jhf7k9D5x7DpYscnY=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.kbho0vimy8.wasm"
    },
    {
      "hash": "sha256-JRwB+nLwZpPCJFlF9iyjZJomGWfYLViPLRO/s0IFlCI=",
      "url": "_framework/Microsoft.Extensions.Configuration.jywwlg86t2.wasm"
    },
    {
      "hash": "sha256-QgeSpS2Wvpjp/LkkamiYvo1WtU65zIukOW27XFu9DKU=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.2b7nsqbm8l.wasm"
    },
    {
      "hash": "sha256-PfDCNF+45F5f+9Ws/7sALxW/Xl1tWb96bog0HLgIS48=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.dkmczoh2d8.wasm"
    },
    {
      "hash": "sha256-acmYTsVYpuSJ1K71pnk9WRJu0wkcZfazrHNctooB5nI=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.z5kud6fak0.wasm"
    },
    {
      "hash": "sha256-7q8VQoiWihCJkMOjtn4bmokmrrpGC4Qb9vD1sd+hw34=",
      "url": "_framework/Microsoft.Extensions.Logging.aexwvosd6d.wasm"
    },
    {
      "hash": "sha256-syZ/EdHmDJuaN70EP4Yx6X2MtqZEbYhjUqvDml8B7yI=",
      "url": "_framework/Microsoft.Extensions.Options.hncluq6jfx.wasm"
    },
    {
      "hash": "sha256-Cn8WJXcSOHGlzR+DpJg8Mqq29YLHD826ahtSc/3CpfM=",
      "url": "_framework/Microsoft.Extensions.Primitives.6gvzf6fvs2.wasm"
    },
    {
      "hash": "sha256-NOXLsCxP8BjUAlEEZGTms8IyAZS4hXC8JOVRe9p4j8I=",
      "url": "_framework/Microsoft.JSInterop.8psms16p1n.wasm"
    },
    {
      "hash": "sha256-wEKmcZize4braYxtDIPNRgttyIs5ZVbqs8eGmdlKy3s=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.0gc968j4pp.wasm"
    },
    {
      "hash": "sha256-vFFwXX6Z0ZMn1BvepWxKycVn5vrFdTfPHVvSfV2kCfQ=",
      "url": "_framework/System.Collections.Concurrent.kiaywedsoh.wasm"
    },
    {
      "hash": "sha256-iF4XthMPX1wdoYdpErGkvspoF87zK6w5mrkOObt5rxY=",
      "url": "_framework/System.Collections.Immutable.svxg3r2k0t.wasm"
    },
    {
      "hash": "sha256-SK29tGJoGBusPeHKjGbwdlXwddeZxLqmFThh9gwhN7Q=",
      "url": "_framework/System.Collections.NonGeneric.cj8uodyh1q.wasm"
    },
    {
      "hash": "sha256-EjwLKIwVXBurE/mHIV8Ud2J5C8NZblzNT2smUf0SVmU=",
      "url": "_framework/System.Collections.Specialized.6i6cw275iw.wasm"
    },
    {
      "hash": "sha256-RL8O8xe02cIDFOh8qiCWBPbmEu5tW0q7wETx6PXQAgc=",
      "url": "_framework/System.Collections.kcge156pzd.wasm"
    },
    {
      "hash": "sha256-2XzyV6DkW9xu0j+GSlFOASZP9eEy1WFK1khh3+MmIVQ=",
      "url": "_framework/System.ComponentModel.948jhz7lkt.wasm"
    },
    {
      "hash": "sha256-NqQIWu5eIMN4RoMte03D8dr6T3GLhwEKiydp8HKKMec=",
      "url": "_framework/System.ComponentModel.Primitives.ei227x2y6f.wasm"
    },
    {
      "hash": "sha256-8ODtRhYltphIA2OwWoFFkhI0w0ofN5YMOfEDcqbKFrU=",
      "url": "_framework/System.ComponentModel.TypeConverter.oanwvhkw2s.wasm"
    },
    {
      "hash": "sha256-Fs7xVPpYJ64gWhxl4HjghPuNhDYWwaXBYkQoWbX3uq0=",
      "url": "_framework/System.Console.qvenfprgcs.wasm"
    },
    {
      "hash": "sha256-G2xz2KJ35MOJFYu9rE7TO0YrbcncN/tu6l6LLgNYiIg=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.5gejwhgn5m.wasm"
    },
    {
      "hash": "sha256-UNLGMpDFITKxuRQ/N5dlu8Lobbd0m+A2jzxpwlEGTJ8=",
      "url": "_framework/System.IO.Compression.w4ct7x4i9r.wasm"
    },
    {
      "hash": "sha256-4yNBZHLIo4FlXuxLKB7/B7GpmmMGiyahydiAZJAxzMs=",
      "url": "_framework/System.IO.Packaging.f1j2vyd5cd.wasm"
    },
    {
      "hash": "sha256-ONdA7TFavpxETEDw0EnrHygQp2nj0mbbjodYTHJ5WIA=",
      "url": "_framework/System.IO.Pipelines.0ukn2jmtqo.wasm"
    },
    {
      "hash": "sha256-BUnSbnh7hd0CWHtzMvRQkNiGLgW+SifpLamxoP5Ha+w=",
      "url": "_framework/System.Linq.1d7nojo89n.wasm"
    },
    {
      "hash": "sha256-9aUtGEEz7vPg+Oqu/uLTZrBwsehqw2LiQnWQ3cFB81k=",
      "url": "_framework/System.Linq.Expressions.fvmx4lvaby.wasm"
    },
    {
      "hash": "sha256-JfusBnJUIH0KmnZkZnFcGfJjBT2RyViz5uYPBwlntbs=",
      "url": "_framework/System.Memory.9b1i8zfndy.wasm"
    },
    {
      "hash": "sha256-BC9CMW+bO62Rih5n+KMwmQMDkl/4d4W4Khs2nvNYV2A=",
      "url": "_framework/System.Net.Http.8l0kh80n33.wasm"
    },
    {
      "hash": "sha256-DSXC4vLXd8J7MqdyYAjZkZPej9FkO/h/9xR755xUMjs=",
      "url": "_framework/System.Net.Primitives.ppv633va7m.wasm"
    },
    {
      "hash": "sha256-Zkc08Zbs1CVQQzRycNGe4LAd1pW/Xe2aEKzV4p+Nrww=",
      "url": "_framework/System.ObjectModel.eum7c3qb7s.wasm"
    },
    {
      "hash": "sha256-WI0sumwmbvyVc1YKT2OIIM4zv/I4lXHJmpcw29YVd7w=",
      "url": "_framework/System.Private.CoreLib.sji3y443sn.wasm"
    },
    {
      "hash": "sha256-+1hYdBSEys/7HMvqfvxuo94hNw68OejPN2qh7m+2Iio=",
      "url": "_framework/System.Private.Uri.5wowddq5qo.wasm"
    },
    {
      "hash": "sha256-dojqTGlB3H1qhQRZD3vPIUHahakbvUbVvFQSBe4+8xk=",
      "url": "_framework/System.Private.Xml.Linq.6c4652coyt.wasm"
    },
    {
      "hash": "sha256-Nr80O2R20iQdbObpd4J6o9DczTckOx9KSJol6OMBJyw=",
      "url": "_framework/System.Private.Xml.i9q9a67xe0.wasm"
    },
    {
      "hash": "sha256-AiQRmKPUUpHhrSFm+q+EOvIQx29+mZa/hRgE9LWA5s8=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.qlnaq3s5oy.wasm"
    },
    {
      "hash": "sha256-ip4xYTK2+WlSh3VLoQg5oqTrZC18yd9K3BQfq5f/EZI=",
      "url": "_framework/System.Runtime.InteropServices.ufdqgup8rk.wasm"
    },
    {
      "hash": "sha256-mXHrjNme1wL2ZcUYgdWSxyQAvMftYe9pNTke3bo3xPI=",
      "url": "_framework/System.Runtime.j5ejoq8aov.wasm"
    },
    {
      "hash": "sha256-ELHY03pae4wIay+Igxwhat4YSbLOfl+TOoSAKvAXGi0=",
      "url": "_framework/System.Security.Cryptography.kzpajvgp7t.wasm"
    },
    {
      "hash": "sha256-IrvJ8CUKsWY1qQ3JDnzO+CYjyKoF/1Id32otpAN53F0=",
      "url": "_framework/System.Text.Encoding.Extensions.uxeizjjpzj.wasm"
    },
    {
      "hash": "sha256-7YsESoBG1RCCl1SVYZwwevmXllOHEOF+KNtsvpG6asE=",
      "url": "_framework/System.Text.Encodings.Web.vp701vtodc.wasm"
    },
    {
      "hash": "sha256-AdkHUYSif5xb7eSszM4gDfCEYoCzJF5y2y0V0VnHgZ4=",
      "url": "_framework/System.Text.Json.h0bx382wkt.wasm"
    },
    {
      "hash": "sha256-boB8mEzCcrYQhMyUy5IJBfNk92e4ZSiaZZif7eZ1nQE=",
      "url": "_framework/System.Text.RegularExpressions.atta3uzey0.wasm"
    },
    {
      "hash": "sha256-FgWJa/l3mXTGDKRiE0k9X5mWWQtuChFACLd/8GEC8RY=",
      "url": "_framework/System.Threading.2ie2xxmcel.wasm"
    },
    {
      "hash": "sha256-ew8aHBMpWxFHtDIWeJCcQgFLBHVr0zxJNrk3WjYqe+8=",
      "url": "_framework/System.Xml.Linq.z25rdwlfbq.wasm"
    },
    {
      "hash": "sha256-5x3GPplpN5WBojtNwBjuek2x2TSs+aU9Kqx4NhXREXU=",
      "url": "_framework/System.l1ekyr7hdn.wasm"
    },
    {
      "hash": "sha256-y3GImn0Cnf7xnd6imxq/JooI7RAqJgz/CWYEab2VCSo=",
      "url": "_framework/Zeugnis.App.5s0th5oe9s.wasm"
    },
    {
      "hash": "sha256-9VFZIXZ3Y2fedXo31/DLTv4wCHcd9Mmc+dSdCBRs0fY=",
      "url": "_framework/Zeugnis.Domain.n58vvdmdzl.wasm"
    },
    {
      "hash": "sha256-xCDZSKg1Wf1EfcQ+DTT6gD9j8o4rBQ4Eh8juSLj5Jvw=",
      "url": "_framework/Zeugnis.Exchange.8zluqbv0pm.wasm"
    },
    {
      "hash": "sha256-sC8cEqNX7e2kuewJV0DhHopozt/s6Kl4YhjEthOExSs=",
      "url": "_framework/Zeugnis.Export.wwvz4oidgn.wasm"
    },
    {
      "hash": "sha256-YW+jKj1nM+feN83xCAd9o1lcIy/lzZTMk/8IBbjXVE4=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-iLDi2PgLsDGL/sJmjQYorsfOKR0qZO2Sw4CxPO15JRQ=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-1feL7t30WjATvx7ccZ3reeAWcqfCss+zjzIz7J+TVuI=",
      "url": "_framework/dotnet.native.1t8lwibe0f.js"
    },
    {
      "hash": "sha256-98MkTi1v3jkQVitwgaAKa17PiWVOcvvHSeqk9GicAag=",
      "url": "_framework/dotnet.native.ngy2llg0wq.wasm"
    },
    {
      "hash": "sha256-MbxvjQiLd0brZSb4DHed2hQtAF5pbvZt/KJigzjZ70w=",
      "url": "_framework/dotnet.runtime.33y5wagaqd.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-/6dgr+BkKcvfyn89xRwlYUD1crqQO93is5gupLim/Hs=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-PjSwZtMCdhf92s4mPK3dNylUMhtpFDi1kZ6klieoqM0=",
      "url": "index.html"
    },
    {
      "hash": "sha256-YDa5q2DuzOSHcVGF07x9ModgK+vi8zyQH6Kx1ZICQVU=",
      "url": "js/zeugnis.js"
    },
    {
      "hash": "sha256-IGTMTc5qS0flMeP2Z1sztOTmL8touvH12EpCcr5tTRw=",
      "url": "manifest.webmanifest"
    }
  ]
};
